Note to the Evaluator:
After submission of this Assignment, I just found out via a rerun of the algorithm that sometimes, 
the performance is degraded by the effect called as Horizon effect. I don't remember this being discussed
in the class. I am very sorry if I had missed that one out. Essentially, the Utility function I have taken 
for this assignment is not good enough for certain cases where there are multiple states giving same
Utility value and as a result, a much longer time is required to get to the final state. This wasn't obvious
to me the first time because the original program was designed as USER vs COMPUTER AI. It won a few times.
The reason why it didn't win as many games like I hoped it would was initially attributed to higher Human 
intelligence and limited depth of search. However, it has come to my attention that poorly designed heuristics
or utility functions in this specific case are more responsible for poor performance.

I have run out of time for testing different heuristics but I am glad that I have encountered this problem 
now rather than never. It is quite insightful to know and program intelligence as utility function. I was
concentrating more on GUI and game mechanics that it never occurred to me to look in this direction, even
when the results of more than 30 reruns are suspicious (now that I have recognized the problem it has become
 rather obvious).

So, I'll be keeping up my efforts to solve this problem over my github link :
https://github.com/Horopter/Artificial_Intelligence_2018/tree/master/AI_Asgnmt_3

Additionally, I have decided to pursue Quiescence search. I could only find a wikipedia link and a name reference
in Russell and Norvig textbook , 2E on page 202.  If time permits, I should be uploading that to the aforesaid link soon.