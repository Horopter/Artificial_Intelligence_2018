#*************************************
#Author : Santosh Kumar Desai
#ID : 2017H1030130P
#*************************************

from gui import *
if __name__=="__main__":
	GUI()